# Fire Arm Moderation Portal

## Files
- `index.html`: applicant-facing form, preserving the original four question categories (50 questions).
- `server.js`: backend that sends applications and signature images to the Discord webhook.
- `.env.example`: template for the private environment variables.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder, run `npm install`.
3. Set `DISCORD_WEBHOOK_URL` in your hosting provider's environment-variable settings. Do not commit a real webhook URL.
4. Run `npm start`.
5. Open the hosted site. The form posts to `/api/applications`.

For local testing, you can copy `.env.example` to `.env` and set the webhook there, then use a dotenv loader or set the environment variable in your terminal. `.env` is excluded by `.gitignore`.

GitHub Pages alone cannot run `server.js`; deploy the Node backend on a Node-capable host and serve the frontend from that same service (or configure a matching API URL).
