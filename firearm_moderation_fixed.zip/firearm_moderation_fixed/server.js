const express = require("express");
const multer = require("multer");
const FormData = require("form-data");

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 2 * 1024 * 1024 }
});

const webhookUrl = process.env.DISCORD_WEBHOOK_URL;
if (!webhookUrl || !/^https:\/\/discord\.com\/api\/webhooks\//.test(webhookUrl)) {
  console.error("Set a valid DISCORD_WEBHOOK_URL environment variable.");
  process.exit(1);
}

app.use(express.static("."));

app.post("/api/applications", upload.single("signature"), async (req, res) => {
  try {
    if (!req.body.application || !req.file) {
      return res.status(400).json({ error: "Application or signature is missing." });
    }
    const application = JSON.parse(req.body.application);
    const { username, discord, knowStaff, staffNames, shareAccount, answers } = application;

    if (![username, discord, knowStaff, shareAccount].every(v => typeof v === "string" && v.trim())) {
      return res.status(400).json({ error: "Please complete all required identity fields." });
    }
    if (!Array.isArray(answers) || answers.length !== 50 ||
        answers.some(a => !a || typeof a.question !== "string" || typeof a.answer !== "string" || !a.answer.trim())) {
      return res.status(400).json({ error: "Please answer all 50 questions." });
    }

    const answerText = answers.map((a, i) =>
      `${i + 1}. ${a.question}\nAnswer: ${a.answer}\n`
    ).join("\n");

    const form = new FormData();
    const payload = {
      username: "Fire Arm Moderation Applications",
      embeds: [{
        title: "New Staff Application",
        color: 16726331,
        fields: [
          { name: "Roblox Username", value: username.slice(0, 1024), inline: true },
          { name: "Discord Username", value: discord.slice(0, 1024), inline: true },
          { name: "Knows Current Staff?", value: knowStaff.slice(0, 1024), inline: true },
          { name: "Known Staff Names", value: (staffNames || "N/A").slice(0, 1024) || "N/A" },
          { name: "Shares Account?", value: shareAccount.slice(0, 1024), inline: true },
          { name: "Full answers", value: "See attached answers.txt" },
          { name: "Signature", value: "Applicant signature attached as PNG." }
        ],
        footer: { text: "Fire Arm Moderation • Staff Portal" },
        timestamp: new Date().toISOString()
      }]
    };

    form.append("payload_json", JSON.stringify(payload));
    form.append("files[0]", Buffer.from(answerText, "utf8"), {
      filename: "answers.txt",
      contentType: "text/plain"
    });
    form.append("files[1]", req.file.buffer, {
      filename: "applicant-signature.png",
      contentType: "image/png"
    });

    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: form.getHeaders(),
      body: form
    });
    if (!response.ok) {
      const details = await response.text();
      console.error("Discord webhook error:", response.status, details);
      return res.status(502).json({ error: "Discord could not accept the application. Please try again later." });
    }
    return res.json({ success: true });
  } catch (error) {
    console.error("Application submission error:", error);
    return res.status(400).json({ error: "Could not process the application." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Fire Arm Moderation portal running on port ${port}`));
